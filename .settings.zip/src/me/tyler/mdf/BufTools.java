package me.tyler.mdf;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.Inflater;

public class BufTools {

	private static final Inflater inflater = new Inflater();
	
	
	public static byte[] compressString(String message) throws IOException{
		byte[] uncompressed = message.getBytes();
		
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		
		DeflaterOutputStream out = new DeflaterOutputStream(bos, new Deflater(Deflater.BEST_COMPRESSION));
		
		out.write(uncompressed);
		out.finish();
		out.close();
		
		return bos.toByteArray();
	}
	/*
	public static String decompressString(byte[] b) throws IOException{
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		InflaterOutputStream in = new InflaterOutputStream(bos);
		
		in.write(b);
		in.finish();
		in.close();
		
		return new String(bos.toByteArray());
	}*/
	
	public static String decompressString(byte[] b) throws IOException{
		try {
			return new String(decompress(b));
		} catch (DataFormatException e) {
			e.printStackTrace();
		}
		return "";
	}
	
	private static byte[] decompress(byte[] data) throws IOException, DataFormatException {
		inflater.setInput(data);
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);
		byte[] buffer = new byte[1024];
		while (!inflater.finished()) {
			int count = inflater.inflate(buffer);
			outputStream.write(buffer, 0, count);
		}
		outputStream.close();
		byte[] output = outputStream.toByteArray();
		return output;
	}
	
	public static int calculateBytesForSVarInt(long number){
		number = (number << 1) ^ (number >> 31);
		
		return calculateBytesForVarInt(number);
	}
	
	public static int calculateBytesForVarInt(long number){
		int numRelevantBits = 64 - Long.numberOfLeadingZeros(number);
		
		int numBytes = (numRelevantBits + 6) / 7;
		
		if(numBytes == 0){
			numBytes = 1;
		}
		
		return numBytes;
	}
	
	public static int readVarInt(InputStream is) throws IOException {

		int value = 0;

		while (true) {
			int tmp = is.read();

			value = (value << 7) | (tmp & 0x7F);

			if ((tmp & 0x80) == 0) {
				break;
			}

		}

		return value;

	}

	// https://github.com/addthis/stream-lib/blob/master/src/main/java/com/clearspring/analytics/util/Varint.java
	public static int readSignedVarInt(InputStream is) throws IOException {

		int raw = readVarInt(is);

		int temp = (((raw << 31) >> 31) ^ raw) >> 1;

		return temp ^ (raw & (1 << 31));

	}

	public static void writeSignedVarInt(long value, OutputStream os) throws IOException {
		writeVarInt((value << 1) ^ (value >> 31), os);
	}

	public static void writeVarInt(long value, OutputStream os) throws IOException {

		int numBytes = calculateBytesForVarInt(value);

		byte[] output = new byte[numBytes];

		for (int i = numBytes - 1; i >= 0; i--) {
			int curByte = (int) (value & 0x7F);
			if (i != (numBytes - 1))
				curByte |= 0x80;
			output[i] = (byte) curByte;
			value >>>= 7;
		}

		os.write(output);

	}

	public static int readVarInt(RandomAccessFile raf) throws IOException {
		return readVarInt(new RandomAccessFileInputStream(raf));
	}
	
}
