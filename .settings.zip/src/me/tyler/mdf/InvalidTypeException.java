package me.tyler.mdf;

public class InvalidTypeException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7433188747223047581L;

	protected InvalidTypeException(String msg) {
		super(msg);
	}
	
}
