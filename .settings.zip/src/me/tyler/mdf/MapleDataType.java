package me.tyler.mdf;

import java.util.HashMap;
import java.util.Map;

public enum MapleDataType {

	NONE(255, false), INTEGER(0, true), SHORT(1, true), FLOAT(2, false), DOUBLE(3, false), STRING(4, false), VECTOR(5, false), LONG(6, true), CANVAS(7, false), BYTE(8, true), COMPRESSED_STRING(9, false);
	
	private static Map<Integer, MapleDataType> types = new HashMap<>();
	
	private final boolean wholeNumber;
	
	static{
		for(MapleDataType type : values()){
			types.put(type.getId(), type);
		}
	}
	
	private final int id;
	
	private MapleDataType(int id, boolean wholeNumber) {
		this.id = id;
		this.wholeNumber = wholeNumber;
	}
	
	public int getId() {
		return id;
	}

	public static MapleDataType getById(int nodeType) {
		return types.get(nodeType);
	}
	
	public boolean isWholeNumber() {
		return wholeNumber;
	}
	
}
