package me.tyler.mdf;

import java.io.File;

public interface MapleFile {

	public long getLoadTime();
	
	public void dispose();
	
	public File getFile();
	
	public Node getRootNode();
	
}
