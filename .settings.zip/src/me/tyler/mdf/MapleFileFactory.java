package me.tyler.mdf;

import java.io.File;
import java.io.IOException;

public class MapleFileFactory {

	public static ReadWriteMapleFile getReadWriteMapleFile(File file) throws IOException{
		return getReadWriteMapleFile(file, true);
	}
	
	public static ReadWriteMapleFile getReadWriteMapleFile(File file, boolean load) throws IOException{
		return new ReadWriteMapleFile(file, true, load);
	}
	
	public static RandomAccessMapleFile getRandomAccessMapleFile(File file) throws IOException{
		return new RandomAccessMapleFile(file);
	}
	
}
