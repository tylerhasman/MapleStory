package me.tyler.mdf;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import me.tyler.mdf.ReadWriteMapleFile.ArrayChildStorage;
import me.tyler.mdf.ReadWriteMapleFile.NodeChildStorage;
import me.tyler.mdf.ReadWriteMapleFile.SingleNodeStorage;

public class MapleNode implements Node {
	
	private static Map<Integer, char[]> stringPool = new HashMap<>();
	private static Map<Integer, Integer> stringPoolReverse = new HashMap<>();
	
	private static Map<Integer, Integer> stringPoolCounter = new HashMap<>();
	private static int stringPoolNextId = 0;
	
	private NodeChildStorage children;
	
	private Object data;
	
	private MapleDataType type;
	
	private int nameKey;
	
	protected MapleNode(Object data, MapleDataType type, String name, int numChildren) {
		if(type == MapleDataType.STRING || type == MapleDataType.COMPRESSED_STRING){
			
			String str = (String) data;
			
			data = registerString(str);
			
		}
		this.data = data;
		this.type = type;
		this.nameKey = registerString(name);
		if(numChildren > 1){
			children = new ArrayChildStorage(new Node[0]);
		}
	}
	
	public static void clearStringPool(){
		stringPool.clear();
		stringPoolReverse.clear();
		stringPoolCounter.clear();
		stringPoolNextId = 0;
	}

	private static int registerString(String str){
		
		if(stringPoolReverse.containsKey(str.hashCode()))	{
			
			int id = stringPoolReverse.get(str.hashCode());
			
			stringPoolCounter.put(id, stringPoolCounter.get(id)+1);
			
			return id;
		}
		
		int nextId = stringPoolNextId++;
		
		stringPool.put(nextId, str.toCharArray());
		stringPoolReverse.put(str.hashCode(), nextId);
		
		stringPoolCounter.put(nextId, 1);
		
		return nextId;
	}
	
	private static String getString(int key){
		if(!stringPool.containsKey(key)){
			return "No String found to key "+key;
		}
		return new String(stringPool.get(key));
	}
	
	@Override
	public int countAllChildren() {
		if(children == null){
			return 0;
		}
		int ch = children.getChildren().length;
		
		for(Node child : children.getChildren()){
			ch += child.countAllChildren();
		}
		
		return ch;
	}
	
	@Override
	public int countAllChildren(MapleDataType type) {
		if(children == null){
			return 0;
		}
		int ch = 0;
		
		for(Node child : children.getChildren()){
			if(child.getType() == type){
				ch++;
			}
			ch += child.countAllChildren(type);
		}
		
		return ch;
	}
	
	@Override
	public void dispose() {
		data = null;
		type = MapleDataType.NONE;
		if(children == null){
			return;
		}
		children.clear();
	}
	
	@Override
	public String getName() {
		return getString(nameKey);
	}
	
	@Override
	public String toString() {
		return getName();
	}
	
	@Override
	public void setType(MapleDataType type) {
		this.type = type;
		data = null;
	}
	
	@Override
	public boolean hasChild(String path) {
		if(children == null){
			return false;
		}
		return children.getNode(path) != null;
	}
	
	@Override
	public void setValue(Object obj) {
		data = obj;
	}
	
	@Override
	public int compareTo(Node o) {
		return getName().compareTo(o.getName());
	}
	
	@Override
	public Node getChild(String path) {
		
		Node node = this;

		if(path.contains("/")){
			String[] parts = path.split("/");
			
			for(int i = 0; i < parts.length;i++){
				if(node == null){
					return null;
				}
				node = node.getChild(parts[i]);
			}
		}else{
			node = readNode(path);
		}
		
		return node;
	}
	
	public Collection<Node> getChildren(){
		if(children == null){
			return Collections.emptyList();
		}
		return Collections.unmodifiableCollection(Arrays.asList(children.getChildren()));
	}
	
	protected void addChild(String key, Node child){
		if(children == null){
			children = new SingleNodeStorage(child);
		}else if(children instanceof SingleNodeStorage){
			Node[] ch = children.getChildren();
			
			children = new ArrayChildStorage(ch);
			children.addNode(key, child);
		}else{
			children.addNode(key, child);	
		}
	}
	
	@Override
	public Node writeCanvasNode(String key) {
		Node node = new MapleNode(null, MapleDataType.CANVAS, key, 0);
		
		addChild(key, node);
		
		return node;
	}
	
	@Override
	public void deleteNode(String key) {
		if(children instanceof SingleNodeStorage){
			children = null;
			return;
		}
		children.removeNode(key);
	}
	
	@Override
	public Node writeNullNode(String key) {
		if(hasChild(key)){
			return children.getNode(key);
		}
		Node node = new MapleNode(null, MapleDataType.NONE, key, 0);
		
		addChild(key, node);
		
		return node;
	}
	
	@Override
	public Node writeInt(String key, int value) {
		Node node = new MapleNode(value, MapleDataType.INTEGER, key, 0);
		
		addChild(key, node);
		
		return node;
	}
	
	@Override
	public Node writeByte(String key, byte value) {
		Node node = new MapleNode(value, MapleDataType.BYTE, key, 0);
		
		addChild(key, node);
		
		return node;
	}
	
	@Override
	public Node writeFloat(String key, float value) {
		Node node = new MapleNode(value, MapleDataType.FLOAT, key, 0);
		
		addChild(key, node);
		
		return node;
	}

	@Override
	public Node writeShort(String key, short value) {
		Node node = new MapleNode(value, MapleDataType.SHORT, key, 0);
		
		addChild(key, node);
		
		return node;
	}

	@Override
	public Node writeDouble(String key, double value) {
		Node node = new MapleNode(value, MapleDataType.DOUBLE, key, 0);
		
		addChild(key, node);
		
		return node;
	}

	@Override
	public Node writeString(String key, String value) {
		Node node = new MapleNode(value, MapleDataType.STRING, key, 0);
		
		addChild(key, node);
		
		return node;
	}
	
	@Override
	public Node writeCompressedString(String key, String value) {
		Node node = new MapleNode(value, MapleDataType.COMPRESSED_STRING, key, 0);
		
		addChild(key, node);
		
		return node;
	}

	@Override
	public Node writeVector(String key, MapleVector vector) {
		Node node = new MapleNode(vector, MapleDataType.VECTOR, key, 0);
		
		addChild(key, node);
		
		return node;
	}
	

	@Override
	public Node writeLong(String key, long value) {
		Node node = new MapleNode(value, MapleDataType.LONG, key, 0);
		
		addChild(key, node);
		
		return node;
	}
	
	@Override
	public Object getValue() {
		if(type == MapleDataType.STRING || type == MapleDataType.COMPRESSED_STRING){
			if(data instanceof Integer){
				return getString((int) data);
			}
		}
		return data;
	}

	@Override
	public Node readNode(String key) {
		if(children == null){
			return null;
		}
		return children.getNode(key);
	}

	@Override
	public MapleDataType getType() {
		return type;
	}

	@Override
	public long readLong(String key) {
		Node node = getChild(key);
		
		if(node == null){
			return 0;
		}
		
		return node.longValue();
	}

	@Override
	public int readInt(String key) {
		Node node = getChild(key);
		
		if(node == null){
			return 0;
		}
		
		return node.intValue();
	}
	
	@Override
	public int readInt(String key, int def) {
		Node node = getChild(key);
		
		if(node == null){
			return def;
		}
		
		return node.intValue();
	}

	@Override
	public short readShort(String key) {
		Node node = getChild(key);
		
		return node.shortValue();
	}
	
	@Override
	public short readShort(String key, short def) {
		Node node = getChild(key);
		
		if(node == null){
			return def;
		}
		
		return node.shortValue();
	}

	@Override
	public byte readByte(String key) {
		return readByte(key, (byte) 0);
	}
	
	@Override
	public byte readByte(String key, byte def) {
		Node node = getChild(key);
		
		if(node == null){
			return def;
		}
		
		return node.byteValue();
	}

	@Override
	public float readFloat(String key) {
		Node node = getChild(key);
		
		if(node == null){
			return 0F;
		}
		
		return node.floatValue();
	}

	@Override
	public double readDouble(String key) {
		Node node = getChild(key);
		
		if(node == null){
			return 0D;
		}
		
		return node.doubleValue();
	}

	@Override
	public String readString(String key) {
		Node node = getChild(key);
		
		if(node == null){
			return null;
		}
		
		return node.stringValue();
	}
	
	@Override
	public String readString(String key, String def) {
		String str = readString(key);
		
		if(str == null){
			return def;
		}
		
		return str;
	}

	@Override
	public MapleVector readVector(String key) {
		Node node = getChild(key);
		
		if(node == null){
			return MapleVector.ZERO;
		}
		
		return node.vectorValue();
	}

	@Override
	public Iterator<Node> iterator() {
		return getChildren().iterator();
	}
	
	@Override
	public long longValue(){
		if(type.isWholeNumber()){
			Number num = (Number) getValue();
			
			return num.longValue();
		}
		if(type == MapleDataType.STRING || type == MapleDataType.COMPRESSED_STRING){
			long value = 0;
			try{
				value = Long.parseLong((String) getValue());
				
				return value;
			}catch(NumberFormatException e){
			}
		}
		return 0L;
	}

	@Override
	public int intValue() {
		return (int) longValue();
	}
	
	@Override
	public short shortValue() {
		return (short) longValue();
	}
	
	@Override
	public byte byteValue() {
		return (byte) longValue();
	}
	
	@Override
	public double doubleValue() {
		
		double d = 0D;
		
		if(type == MapleDataType.DOUBLE || type == MapleDataType.FLOAT){
			Number number = (Number) getValue();
			
			d = number.doubleValue();
		}else if(type == MapleDataType.STRING || type == MapleDataType.COMPRESSED_STRING){
			try{
				d = Double.parseDouble(stringValue());
			}catch(NumberFormatException e){
			}
		}
		
		return d;
	}
	
	@Override
	public float floatValue() {
		return (float) doubleValue();
	}
	
	@Override
	public String stringValue() {
		if(getValue() == null){
			return "";
		}
		return getValue().toString();
	}
	
	@Override
	public MapleVector vectorValue() {
		if(type == MapleDataType.VECTOR){
			return (MapleVector) getValue();
		}
		return MapleVector.ZERO;
	}


}
