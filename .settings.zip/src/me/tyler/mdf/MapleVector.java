package me.tyler.mdf;

import java.awt.Point;

public class MapleVector {

	public static final MapleVector ZERO = new MapleVector((short) 0, (short) 0);
	
	private short x, y;
	
	public MapleVector(short x, short y) {
		this.x = x;
		this.y = y;
	}
	
	public MapleVector(Point data) {
		this((short) data.x, (short) data.y);
	}

	public short getX() {
		return x;
	}
	
	
	public short getY() {
		return y;
	}
	
	@Override
	public String toString() {
		return x+" "+y;
	}

	public Point toPoint() {
		return new Point(x, y);
	}
	
}
