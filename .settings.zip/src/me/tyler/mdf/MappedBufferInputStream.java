package me.tyler.mdf;

import java.io.IOException;
import java.io.InputStream;
import java.nio.MappedByteBuffer;

public class MappedBufferInputStream extends InputStream {

	private MappedByteBuffer buffer;
	
	public MappedBufferInputStream(MappedByteBuffer buffer) {
		this.buffer = buffer;
	}
	
	@Override
	public int read() throws IOException {

		int buf = buffer.get() & 0xFF;
		
		return buf;
	}
	
	@Override
	public void close() throws IOException {
		buffer.clear();
		super.close();
	}
	
}