package me.tyler.mdf;

import java.util.Collection;

public interface Node extends Writeable, Readable, Comparable<Node>, Iterable<Node> {

	public Object getValue();
	
	public Collection<Node> getChildren();
	
	public MapleDataType getType();
	
	public Node getChild(String path);
	
	public String getName();

	public void setValue(Object obj);

	public void setType(MapleDataType type);
	
	public boolean hasChild(String path);
	
	public void dispose();

	public long longValue();
	
	public int intValue();
	
	public short shortValue();
	
	public byte byteValue();
	
	public MapleVector vectorValue();
	
	public String stringValue();
	
	public float floatValue();
	
	public double doubleValue();
	
	public void deleteNode(String key);

	public int countAllChildren();

	public int countAllChildren(MapleDataType type);
	
}
