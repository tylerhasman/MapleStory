package me.tyler.mdf;

public class NodeParseException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6333246936845532371L;

	public NodeParseException(String name) {
		super(name);
	}
	
	
	
}
