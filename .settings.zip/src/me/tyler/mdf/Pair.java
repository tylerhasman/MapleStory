package me.tyler.mdf;

public class Pair<A, B> {

	private A key;
	private B value;
	
	public Pair(A a, B b) {
		key = a;
		value = b;
	}
	
	
	public A getKey() {
		return key;
	}
	
	public B getValue() {
		return value;
	}
	
	
	@Override
	public int hashCode() {
		return key.hashCode() * 13 + (value == null ? 0 : value.hashCode());
	}
	
	@Override
	public boolean equals(Object obj) {
		if(this == obj){
			return true;
		}
		if(obj instanceof Pair){
			Pair<?, ?> pair = (Pair<?, ?>) obj;
			
			if (key != null ? !key.equals(pair.key) : pair.key != null) return false;
            if (value != null ? !value.equals(pair.value) : pair.value != null) return false;
            return true;
		}
		return false;
	}
	
}
