package me.tyler.mdf;

import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;

public class RandomAccessFileInputStream extends InputStream {

	private RandomAccessFile raf;
	
	public RandomAccessFileInputStream(RandomAccessFile raf) {
		this.raf = raf;
	}
	
	@Override
	public int read() throws IOException {
		return raf.read();
	}

}
