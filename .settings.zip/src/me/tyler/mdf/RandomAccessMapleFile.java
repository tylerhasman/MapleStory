package me.tyler.mdf;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class RandomAccessMapleFile implements MapleFile {
	
	private RandomAccessNode rootNode;
	
	private final File file;
	
	private RandomAccessFile raf;
	
	private Lock fileLock;
	
	protected RandomAccessMapleFile(File file) throws IOException {
		
		this.file = file;
		
		fileLock = new ReentrantLock(true);
		
		raf = new RandomAccessFile(file, "r");
		
		loadRoot();
		
	}
	
	private Object readData(MapleDataType type) throws IOException {
		
		if(type == MapleDataType.INTEGER){
			return raf.readInt();
		}else if(type == MapleDataType.SHORT){
			return raf.readShort();
		}else if(type == MapleDataType.LONG){
			return raf.readLong();
		}else if(type == MapleDataType.STRING){
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			
			int b;
			
			while((b = raf.read()) > 0){
				bos.write(b);
			}
			
			String s = new String(bos.toByteArray());
			
			return s;
		}else if(type == MapleDataType.COMPRESSED_STRING){
			
			int length = raf.readShort();
			
			byte[] strData = new byte[length];
			
			raf.read(strData);
			
			String decomp = BufTools.decompressString(strData);
			
			return decomp;
			
		}else if(type == MapleDataType.VECTOR){
			
			short x, y;
			
			x = raf.readShort();
			y = raf.readShort();
			
			return new MapleVector(x, y);
		}else if(type == MapleDataType.FLOAT){

			float value = raf.readFloat();
			
			return value;
		}else if(type == MapleDataType.DOUBLE){

			double value = raf.readDouble();
			
			return value;
		}else if(type == MapleDataType.BYTE){
			return (byte) raf.read();
		}
		
		return null;
	}
	
	public List<RandomAccessNode> readNodes(long memoryLocation, int amount) throws IOException{
		
		fileLock.lock();
		
		try{
			
			List<RandomAccessNode> nodes = new ArrayList<>(amount);
			
			raf.seek(memoryLocation);
			
			for(int i = 0; i < amount;i++){
				nodes.add(readNode());
			}
			
			return nodes;
			
		}finally{
			fileLock.unlock();
		}
		
	}
	
	private RandomAccessNode readNode() throws IOException{
		String name = raf.readUTF();
		
		int nodeType = raf.read();
		
		MapleDataType type = MapleDataType.getById(nodeType);
		
		if(type == null){
			throw new NodeParseException("Unknown node type "+nodeType);
		}
		
		Object data = readData(type);
		
		int children = BufTools.readVarInt(raf);
		
		int childrenSize = BufTools.readVarInt(raf);
		
		long childrenPos = raf.getFilePointer();
		
		raf.skipBytes(childrenSize);
		
		RandomAccessNode node = new RandomAccessNode(data, type, name, children, childrenPos, this);
		
		return node;
	}
	
	private void loadRoot() throws IOException {
		
		fileLock.lock();
		
		try{
			raf.seek(0);
			int rootChildren = BufTools.readVarInt(raf);
			
			rootNode = new RandomAccessNode(null, MapleDataType.NONE, "root", rootChildren, raf.getFilePointer(), this);
			
		}finally{
			fileLock.unlock();
		}
		
	}
	
	@Override
	public long getLoadTime() {
		return 0;
	}

	@Override
	public void dispose() {
		rootNode.dispose();
		try {
			raf.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		MapleNode.clearStringPool();
		System.gc();
	}

	@Override
	public File getFile() {
		return file;
	}

	@Override
	public Node getRootNode() {
		return rootNode;
	}

}
