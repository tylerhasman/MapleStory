package me.tyler.mdf;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

public class RandomAccessNode extends MapleNode {

	private final long childrenMemoryLocation;
	private final RandomAccessMapleFile file;
	
	private boolean childrenLoaded;
	
	private int numChildren;
	
	protected RandomAccessNode(Object data, MapleDataType type, String name, int numChildren, long childrenMemoryLocation, RandomAccessMapleFile mf) {
		super(data, type, name, numChildren);
		this.numChildren = numChildren;
		this.childrenMemoryLocation = childrenMemoryLocation;
		this.file = mf;
		childrenLoaded = false;
	}
	
	@Override
	public Node readNode(String key) {
		try {
			loadChildren();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return super.readNode(key);
	}
	
	private void loadChildren() throws IOException{
		
		if(childrenLoaded){
			return;
		}
		childrenLoaded = true;
		
		List<RandomAccessNode> nodes = file.readNodes(childrenMemoryLocation, numChildren);
		
		for(RandomAccessNode child : nodes){
			addChild(child.getName(), child);
		}
		
	}
	
	@Override
	public Collection<Node> getChildren() {
		try {
			loadChildren();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return super.getChildren();
	}
	
	@Override
	public Node getChild(String path) {
		try {
			loadChildren();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return super.getChild(path);
	}

}
