package me.tyler.mdf;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

public class ReadWriteMapleFile implements MapleFile {

	private final File file;
	
	private Node rootNode;
	
	private boolean writable;
	
	private long loadTime;
	
	protected ReadWriteMapleFile(File file, boolean writable, boolean load) throws IOException {
		
		this.file = file;
		rootNode = new MapleNode(null, MapleDataType.NONE, "root", 0);
		this.writable = writable;
		if(load){
			loadTime = System.currentTimeMillis();
			read();
			loadTime = System.currentTimeMillis() - loadTime;
		}
		
	}
	
	public ReadWriteMapleFile(File file) throws IOException {
		this(file, false, true);
	}
	
	public void dispose(){
		rootNode.dispose();
	}
	
	public long getLoadTime() {
		return loadTime;
	}
	
	public void write() throws IOException {
		
		write(file);
		
	}
	
	public void write(File file) throws IOException{
		try(DataOutputStream fos = new DataOutputStream(new FileOutputStream(file))){
			BufTools.writeVarInt(rootNode.getChildren().size(), fos);
			
			for(Node child : rootNode.getChildren()){
				writeNode(fos, child);
			}	
		}
	}
	
	private MapleNode internalRead(InputStream is) throws IOException{
		DataInputStream dis = new DataInputStream(is);
		
		int rootChildren = BufTools.readVarInt(dis);
		MapleNode root = new MapleNode(null, MapleDataType.NONE, "root", rootChildren);
		
		for(int i = 0; i < rootChildren;i++){
			Pair<String, Node> child = readNode(dis);
			
			if(child.getValue() == null){
				continue;
			}
			
			root.addChild(child.getKey(), child.getValue());
		}
		
		dis.close();
	
		return root;
	}
	
	private void fastRead() throws IOException{
		
		FileChannel channel;
		MappedByteBuffer buffer;
		
		try(FileInputStream stream = new FileInputStream(file)){
			channel = stream.getChannel();
			buffer = channel.map(MapMode.READ_ONLY, 0, file.length());
			try(MappedBufferInputStream bis = new MappedBufferInputStream(buffer)){
				
				MapleNode root = internalRead(bis);
				
				buffer.clear();
				channel.close();
				bis.close();

				rootNode = root;
			}

		}
		
	}
	
	private void slowRead() throws IOException {
		MapleNode root = null;
		try(FileInputStream fis = new FileInputStream(file)){
			
			BufferedInputStream bis = new BufferedInputStream(fis);
			
			root = internalRead(bis);
			
			bis.close();
			
		}
		rootNode = root;
	}
	
	private void read() throws IOException{
		
		if(!file.exists()){
			return;
		}
		
		if(!writable){
			fastRead();
		}else{
			slowRead();
		}
		
	}
	
	private Pair<String, Node> readNode(DataInputStream is) throws IOException{
		String name = is.readUTF();
		try{
			
			int nodeType = is.read();
			
			MapleDataType type = MapleDataType.getById(nodeType);
			
			if(type == null){
				System.err.println("Unknown node type "+nodeType);
				type = MapleDataType.NONE;
				throw new NodeParseException(name);
			}
			
			
			Object data = readData(is, type);
			
			int children = BufTools.readVarInt(is);
			int childrenSize = BufTools.readVarInt(is);//We dont need this, its for random access
			
			List<Node> childrenList = new ArrayList<>();
			
			for(int i = 0; i < children;i++){
				Pair<String, Node> child = readNode(is);
				
				if(child.getValue() == null){
					continue;
				}
				
				childrenList.add(child.getValue());
			}
			
			MapleNode node = new MapleNode(data, type, name, childrenList.size());
			
			for(Node ch : childrenList){
				node.addChild(ch.getName(), ch);
			}
			
			return new Pair<String, Node>(name, node);
		}catch(Exception e){
			e.printStackTrace();
			if(e.getMessage() == null){
				throw new NodeParseException(name+" -> "+e.getClass().getSimpleName()+" "+e.getStackTrace()[0].toString());
			}else{
				throw new NodeParseException(name+" -> "+e.getMessage());
			}
			
		}
	}

	private void writeNode(DataOutputStream fos, Node node) throws IOException{
		
		Collection<Node> children = node.getChildren();
		
		String key = node.getName();
		
		fos.writeUTF(key);
		
		fos.write(node.getType().getId());
		
		writeData(fos, node);
		
		BufTools.writeVarInt(children.size(), fos);
		
		fos.flush();
		
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		
		for(Node child : children){
			writeNode(new DataOutputStream(bos), child);
		}
		
		BufTools.writeVarInt(bos.size(), fos);
		fos.write(bos.toByteArray());
		
		fos.flush();
		
	}
	
	private Object readData(DataInputStream dis, MapleDataType type) throws IOException {
		
		if(type == MapleDataType.INTEGER){
			return dis.readInt();
		}else if(type == MapleDataType.SHORT){
			return dis.readShort();
		}else if(type == MapleDataType.LONG){
			return dis.readLong();
		}else if(type == MapleDataType.STRING){
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			
			int b;
			
			while((b = dis.read()) > 0){
				bos.write(b);
			}
			
			String s = new String(bos.toByteArray());
			
			return s;
		}else if(type == MapleDataType.COMPRESSED_STRING){
			
			int length = dis.readShort();
			
			byte[] strData = new byte[length];
			
			dis.read(strData);
			
			String decomp = BufTools.decompressString(strData);
			
			return decomp;
			
		}else if(type == MapleDataType.VECTOR){
			
			short x, y;
			
			x = dis.readShort();
			y = dis.readShort();
			
			return new MapleVector(x, y);
		}else if(type == MapleDataType.FLOAT){

			float value = dis.readFloat();
			
			return value;
		}else if(type == MapleDataType.DOUBLE){

			double value = dis.readDouble();
			
			return value;
		}else if(type == MapleDataType.BYTE){
			return (byte) dis.read();
		}
		
		return null;
	}
	
	private void writeData(OutputStream os, Node node) throws IOException{
		DataOutputStream dos = new DataOutputStream(os);
		if(node.getType() == MapleDataType.INTEGER){
			int value = node.intValue();
			
			dos.writeInt(value);
			
		}else if(node.getType() == MapleDataType.SHORT){
			short value = node.shortValue();

			dos.writeShort(value);
			
		}else if(node.getType() == MapleDataType.LONG){
			long value = node.longValue();
			
			dos.writeLong(value);
			
		}else if(node.getType() == MapleDataType.STRING){
			
			String value = node.stringValue();
			
			byte[] payload = value.getBytes();
		
			dos.write(payload);
			dos.write(0);
		}else if(node.getType() == MapleDataType.COMPRESSED_STRING){
			
			String value = node.stringValue();
			
			byte[] payload = BufTools.compressString(value);
			
			dos.writeShort(payload.length);
			
			dos.write(payload);
			
		}else if(node.getType() == MapleDataType.VECTOR){
			
			MapleVector vector = node.vectorValue();
			
			short x = vector.getX();
			short y = vector.getY();
			
			dos.writeShort(x);
			dos.writeShort(y);
				
		}else if(node.getType() == MapleDataType.FLOAT){
			float value = node.floatValue();
			
			dos.writeFloat(value);
		}else if(node.getType() == MapleDataType.DOUBLE){
			double value = node.doubleValue();

			dos.writeDouble(value);
		}else if(node.getType() == MapleDataType.BYTE){
			dos.write(node.byteValue());
		}
		
	}
	
	public File getFile() {
		return file;
	}
	
	public Node getRootNode() {
		return rootNode;
	}
	
	static interface NodeChildStorage {
		
		public Node getNode(String key);
		
		public void addNode(String key, Node node);
		
		public Node[] getChildren();
		
		public void clear();

		public void removeNode(String key);
		
	}
	
	static class ArrayChildStorage implements NodeChildStorage {

		private Node[] nodes;
		
		public ArrayChildStorage(Node[] nodes) {
			this.nodes = nodes;
		}
		
		private int indexOf(String key){
			for(int i = 0; i < nodes.length;i++){
				Node node = nodes[i];
				if(node.getName().equals(key)){
					return i;
				}
			}
			return -1;
		}
		
		@Override
		public Node getNode(String key) {
			
			int index = indexOf(key);
			
			if(index >= 0){
				return nodes[index];
			}
			
			return null;
		}
		
		@Override
		public void removeNode(String key) {
			int index = indexOf(key);
			
			Node[] newNodes = new Node[nodes.length-1];
			
			if(index >= 0){
				int j = 0;
				for(int i = 0; i < nodes.length;i++){
					
					if(i == index){
						continue;
					}
					
					newNodes[j] = nodes[i];
					
					j++;
				}
			}
			
			nodes = newNodes;
			
		}
		
		@Override
		public Node[] getChildren() {
			return nodes;
		}
		

		@Override
		public void addNode(String key, Node node) {
			int index = indexOf(key);
			
			if(index >= 0){
				nodes[index] = node;
			}else{
				nodes = Arrays.copyOf(nodes, nodes.length+1);
				
				nodes[nodes.length-1] = node;
			}
		}
		
		@Override
		public void clear() {
			for(Node node : nodes){
				node.dispose();
			}
			nodes = null;
		}
		
	}
	
	static class SingleNodeStorage implements NodeChildStorage {
		
		private final Node node;
		
		public SingleNodeStorage(Node node) {
			this.node = node;
		}
		
		@Override
		public Node getNode(String key) {
			if(key.equals(node.getName())){
				return node;
			}
			return null;
		}

		@Override
		public void addNode(String key, Node node) {
			throw new IllegalStateException("Cannot add nodes to single node storage");
		}
		
		@Override
		public Node[] getChildren() {
			return new Node[] { node };
		}
		
		@Override
		public void removeNode(String key) {
			
		}
		
		@Override
		public void clear() {
			
		}
		
	}
	
}
