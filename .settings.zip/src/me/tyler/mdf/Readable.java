package me.tyler.mdf;

public interface Readable {

	public Node readNode(String key);
	
	public long readLong(String key);
	
	public int readInt(String key);
	
	public int readInt(String key, int def);
	
	public short readShort(String key);
	
	public short readShort(String key, short def);
	
	public byte readByte(String key);

	public byte readByte(String key, byte def);

	public float readFloat(String key);
	
	public double readDouble(String key);
	
	public String readString(String key);
	
	public String readString(String key, String def);
	
	public MapleVector readVector(String key);
	
}
