package me.tyler.mdf;

public interface Writeable {

	public Node writeInt(String key, int value);
	
	public Node writeShort(String key, short value);
	
	public Node writeFloat(String key, float value);
	
	public Node writeDouble(String key, double value);
	
	public Node writeString(String key, String value);
	
	public Node writeCompressedString(String key, String value);
	
	public Node writeVector(String key, MapleVector vector);

	public Node writeByte(String key, byte value);
	
	public Node writeLong(String key, long value);

	public Node writeNullNode(String key);
	
	public Node writeCanvasNode(String key);
	
}
