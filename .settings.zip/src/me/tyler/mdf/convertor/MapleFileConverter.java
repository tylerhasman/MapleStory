package me.tyler.mdf.convertor;

import java.io.File;

import me.tyler.mdf.MapleFile;

public interface MapleFileConverter<T> {

	public MapleFile convert(File out, T t) throws Exception;
	
}
