package me.tyler.mdf.gui;

import java.awt.EventQueue;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.filechooser.FileFilter;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import javax.swing.JButton;

import me.tyler.mdf.MapleDataType;
import me.tyler.mdf.MapleFileFactory;
import me.tyler.mdf.MapleVector;
import me.tyler.mdf.Node;
import me.tyler.mdf.RandomAccessMapleFile;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JTextArea;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JComboBox;

public class MapleFileExplorer {

	private JFrame frame;
	private Node selected;
	private RandomAccessMapleFile mf;
	private JTextField newChildName;
	
	/**
	 * Launch the application.
	 * @throws UnsupportedLookAndFeelException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws ClassNotFoundException 
	 */
	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MapleFileExplorer window = new MapleFileExplorer();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MapleFileExplorer() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		JLabel lblNoUnsavedChanges = new JLabel("");
		JTextArea selectedValue = new JTextArea();
		selectedValue.setLineWrap(true);
		frame = new JFrame();
		JComboBox<MapleDataType> dataTypes = new JComboBox<>();
		frame.setBounds(100, 100, 541, 513);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JTree tree = new JTree();
		tree.setVisibleRowCount(1000);
		tree.setModel(new DefaultTreeModel(
			new DefaultMutableTreeNode("choose a file") {
				/**
				 * 
				 */
				private static final long serialVersionUID = 6394728798940668052L;

			}
		));
		tree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
		tree.addTreeSelectionListener(new TreeSelectionListener() {
			
			@Override
			public void valueChanged(TreeSelectionEvent e) {
				if(e.getNewLeadSelectionPath() == null){
					selectedValue.setText("no value");
					return;
				}
				Object obj = e.getNewLeadSelectionPath().getLastPathComponent();
				
				Node node = (Node) obj;
				
				selected = node;
				
				dataTypes.setSelectedItem(node.getType());
				
				selectedValue.setText(node.getValue() == null ? "no value" : node.getValue().toString());
			}
		});
		tree.setBounds(10, 11, 435, 267);
		frame.getContentPane().add(tree);
		
		JButton btnSelectFile = new JButton("Select File");
		btnSelectFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser choose = new JFileChooser();
				choose.setMultiSelectionEnabled(false);
				choose.setFileFilter(new FileFilter() {
					
					@Override
					public String getDescription() {
						return "MapleDataFile .mdf";
					}
					
					@Override
					public boolean accept(File f) {
						if(f.getName().endsWith(".mdf") || f.isDirectory()){
							return true;
						}
						return false;
					}
				});
				int result = choose.showOpenDialog(MapleFileExplorer.this.frame);

				if(result == JFileChooser.APPROVE_OPTION){
					File file = choose.getSelectedFile();
					
					if(mf != null){
						mf.dispose();
					}
					
					try {
						mf = MapleFileFactory.getRandomAccessMapleFile(file);
						
						tree.setModel(new MapleFileTreeModel(mf, MapleFileExplorer.this));
						
					} catch (IOException e1) {
						e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "An error occured while parsing the file.");
					}
				}
				
			}
		});
		btnSelectFile.setBounds(40, 11, 158, 23);
		frame.getContentPane().add(btnSelectFile);
		
		JScrollPane scrollPane = new JScrollPane(tree);
		scrollPane.setBounds(38, 56, 437, 284);
		frame.getContentPane().add(scrollPane);
		
		JLabel lblSelectedValue = new JLabel("Selected Value");
		lblSelectedValue.setBounds(30, 351, 74, 14);
		frame.getContentPane().add(lblSelectedValue);
		
		JButton btnWriteValue = new JButton("Write Value");
		btnWriteValue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Object value = null;
				String n = selectedValue.getText();
				
				
				selected.setType((MapleDataType) dataTypes.getSelectedItem());
				
				switch(selected.getType()){
				case INTEGER:
					value = Integer.parseInt(n);
					break;
				case LONG:
					value = Long.parseLong(n);
					break;
				case COMPRESSED_STRING:
				case STRING:
					value = n;
					break;
				case DOUBLE:
					value = Double.parseDouble(n);
					break;
				case FLOAT:
					value = Float.parseFloat(n);
					break;
				case VECTOR:
					String[] components = n.split(" ");
					short x = Short.parseShort(components[0]);
					short y = Short.parseShort(components[1]);
					value = new MapleVector(x, y);
					break;
				case SHORT:
					value = Short.parseShort(n);
				default:
					break;
				}
				
				selected.setValue(value);
				lblNoUnsavedChanges.setText("Unsaved changes!!!!");
				
			}
		});
		btnWriteValue.setBounds(15, 370, 89, 23);
		frame.getContentPane().add(btnWriteValue);
		
		selectedValue.setBounds(109, 353, 368, 50);
		frame.getContentPane().add(selectedValue);
		
		JButton btnSaveChanges = new JButton("Save Changes");
		btnSaveChanges.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent event) {
				
				/*try {
					mf.write();
					lblNoUnsavedChanges.setText("Saved!");
				} catch (IOException e) {
					e.printStackTrace();
				}*/
				
				lblNoUnsavedChanges.setText("Save disabled!");

				
			}
		});
		btnSaveChanges.setBounds(284, 11, 130, 23);
		frame.getContentPane().add(btnSaveChanges);
		
		lblNoUnsavedChanges.setBounds(385, 34, 130, 14);
		frame.getContentPane().add(lblNoUnsavedChanges);
		
		dataTypes.setBounds(105, 414, 113, 23);
		for(MapleDataType type : MapleDataType.values()){
			dataTypes.addItem(type);
		}
		frame.getContentPane().add(dataTypes);
		
		JButton btnCreateChild = new JButton("Create Child");
		btnCreateChild.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				selected.writeNullNode(newChildName.getText());
				TreePath path = tree.getSelectionPath();
				tree.setModel(new MapleFileTreeModel(mf, MapleFileExplorer.this));
				tree.expandPath(path);
			}
		});
		btnCreateChild.setBounds(264, 428, 130, 23);
		frame.getContentPane().add(btnCreateChild);
		
		newChildName = new JTextField();
		newChildName.setBounds(405, 429, 86, 20);
		frame.getContentPane().add(newChildName);
		newChildName.setColumns(10);
		
		JButton btnDeleteNode = new JButton("Delete Node");
		btnDeleteNode.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				Node parent = findParent(mf.getRootNode(), selected);
				
				if(parent == null){
					JOptionPane.showMessageDialog(null, "No parent found for that node");
				}else{
					parent.deleteNode(selected.getName());
					JOptionPane.showMessageDialog(null, "Node cleared.");
					TreePath path = tree.getSelectionPath();
					tree.setModel(new MapleFileTreeModel(mf, MapleFileExplorer.this));
					tree.expandPath(path);
					lblNoUnsavedChanges.setText("Unsaved changes!!!!");
				}
			}
		});
		btnDeleteNode.setBounds(15, 440, 130, 23);
		frame.getContentPane().add(btnDeleteNode);
		
		new Thread(() -> {
			while(true){
				updateTitle();
				try {
					Thread.sleep(50);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
			}
		}).start();
		frame.setResizable(false);
	}
	
	private void updateTitle() {
		if(mf == null){
			return;
		}
		long total = Runtime.getRuntime().totalMemory();
		long free = Runtime.getRuntime().freeMemory();
		long used = total - free;
		frame.setTitle("Editting "+mf.getFile().getName()+" Memory "+(used / 1024 / 1024)+"MB / "+(total / 1024 / 1024)+"MB");
	}

	private Node findParent(Node top, Node node){
		for(Node child : top){
			if(child == node){
				return top;
			}
			Node found = findParent(child, node);
			
			if(found != null){
				return found;
			}
		}
		return null;
	}
	
}
