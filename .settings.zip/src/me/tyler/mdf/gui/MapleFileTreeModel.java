package me.tyler.mdf.gui;

import java.util.stream.Collectors;

import javax.swing.event.TreeModelListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

import me.tyler.mdf.Node;
import me.tyler.mdf.RandomAccessMapleFile;

public class MapleFileTreeModel implements TreeModel {

	private RandomAccessMapleFile file;
	
	private MapleFileExplorer exp;
	
	public MapleFileTreeModel(RandomAccessMapleFile file, MapleFileExplorer mapleFileExplorer) {
		this.file = file;
		exp = mapleFileExplorer;
	}
	
	@Override
	public void addTreeModelListener(TreeModelListener l) {
		
	}

	@Override
	public Object getChild(Object parent, int index) {
		Node mapleNode = (Node) parent;
		
		for(Node node : mapleNode.getChildren().stream().sorted().collect(Collectors.toList())){
			if(index == 0){
				return node;
			}
			index--;
		}
		
		return null;
	}

	@Override
	public int getChildCount(Object parent) {
		Node mapleNode = (Node) parent;
		return mapleNode.getChildren().size();
	}

	@Override
	public int getIndexOfChild(Object parent, Object child) {
		Node mapleNode = (Node) parent;
		Node mapleNodeChild = (Node) child;
		
		int i = 0;
		
		for(Node node : mapleNode.getChildren()){
			if(node.getName().equals(mapleNodeChild.getName())){
				return i;
			}
			i++;
		}
		
		return -1;
	}

	@Override
	public Object getRoot() {
		return file.getRootNode();
	}

	@Override
	public boolean isLeaf(Object node) {
		Node mapleNode = (Node) node;
		
		return mapleNode.getChildren().size() == 0;
	}

	@Override
	public void removeTreeModelListener(TreeModelListener l) {
		
	}

	@Override
	public void valueForPathChanged(TreePath path, Object newValue) {
		
	}


}
