package me.tyler.mdf.io;

import java.io.IOException;
import java.io.InputStream;

public class MapleNodeInputStream extends InputStream {
	
	private InputStream parent;
	
	public MapleNodeInputStream(InputStream is) {
		parent = is;
	}
	
	
	
	@Override
	public int read() throws IOException {
		
		return 0;
	}
	
	@Override
	public void close() throws IOException {
		parent.close();
	}

}
