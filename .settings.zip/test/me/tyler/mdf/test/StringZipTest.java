package me.tyler.mdf.test;

import static org.junit.Assert.*;

import java.io.IOException;

import me.tyler.mdf.BufTools;

import org.junit.Test;

public class StringZipTest {

	@Test
	public void test() throws IOException {
		String string = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABBBBBBBBBBBBBBBBBBBBBBBBBB";
		
		byte[] bts = BufTools.compressString(string);
		
		System.out.println("Compressed from "+string.getBytes().length+" to "+bts.length);
	
		String uncompressed = BufTools.decompressString(bts);
		
		if(string.equals(uncompressed)){
			System.out.println("It is equal!");
		}else{
			fail("Strings are not equal! "+string+" and "+uncompressed);
		}
	}

}
